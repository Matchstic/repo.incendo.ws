'use strict';


customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`
        <nav>
            <ul class="list">
                <li class="title">
                    <a href="index.html" data-type="index-link"><h3>Xen HTML API</h3></a>
                </li>

                <li class="divider"></li>
                ${ isNormalMode ? `` : '' }
                <li class="chapter">
                    <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
                    <ul class="links">
                        <li class="link">
                            <a href="index.html" data-type="chapter-link">
                                <span class="icon ion-ios-keypad"></span>Introduction
                            </a>
                        </li>

                                    <li class="chapter inner">
                                        <a data-type="chapter-link" href="additional-documentation/syntax:-javascript.html" data-context-id="additional">
                                            <div class="menu-toggler linked">
                                                <span class="link-name"><span class="icon ion-ios-paper"></span>Syntax: JavaScript</span>
                                            </div>
                                        </a>
                                        <ul class="links">
                                            <li class="link for-chapter2">
                                                <a href="additional-documentation/syntax:-javascript/native-apis.html" data-type="entity-link" data-context="sub-entity" data-context-id="additional">Native APIs</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="chapter inner">
                                        <a data-type="chapter-link" href="additional-documentation/syntax:-inline-data.html" data-context-id="additional">
                                            <div class="menu-toggler linked">
                                                <span class="link-name"><span class="icon ion-ios-paper"></span>Syntax: Inline Data</span>
                                            </div>
                                        </a>
                                        <ul class="links">
                                            <li class="link for-chapter2">
                                                <a href="additional-documentation/syntax:-inline-data/usage.html" data-type="entity-link" data-context="sub-entity" data-context-id="additional">Usage</a>
                                            </li>
                                            <li class="link for-chapter2">
                                                <a href="additional-documentation/syntax:-inline-data/formatters.html" data-type="entity-link" data-context="sub-entity" data-context-id="additional">Formatters</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="chapter inner">
                                        <a data-type="chapter-link" href="additional-documentation/widget-setup.html" data-context-id="additional">
                                            <div class="menu-toggler linked">
                                                <span class="link-name"><span class="icon ion-ios-paper"></span>Widget Setup</span>
                                            </div>
                                        </a>
                                        <ul class="links">
                                            <li class="link for-chapter2">
                                                <a href="additional-documentation/widget-setup/layout.html" data-type="entity-link" data-context="sub-entity" data-context-id="additional">Layout</a>
                                            </li>
                                            <li class="link for-chapter2">
                                                <a href="additional-documentation/widget-setup/configuration.html" data-type="entity-link" data-context="sub-entity" data-context-id="additional">Configuration</a>
                                            </li>
                                            <li class="link for-chapter2">
                                                <a href="additional-documentation/widget-setup/examples.html" data-type="entity-link" data-context="sub-entity" data-context-id="additional">Examples</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="link ">
                                        <a href="additional-documentation/resource-packs.html" data-type="chapter-link">
                                            <span class="icon ion-ios-paper"></span>Resource Packs
                                        </a>
                                    </li>
                                    <li class="link ">
                                        <a href="additional-documentation/url-scheme-handling.html" data-type="chapter-link">
                                            <span class="icon ion-ios-paper"></span>URL Scheme Handling
                                        </a>
                                    </li>
                                    <li class="link ">
                                        <a href="additional-documentation/logging.html" data-type="chapter-link">
                                            <span class="icon ion-ios-paper"></span>Logging
                                        </a>
                                    </li>
                                    <li class="link ">
                                        <a href="additional-documentation/emulation.html" data-type="chapter-link">
                                            <span class="icon ion-ios-paper"></span>Emulation
                                        </a>
                                    </li>
                    </ul>
                </li>
                    <li class="chapter">
                        <div class="simple">
                            <span class="icon ion-md-analytics"></span>
                            <span>Data Providers</span>
                        </div>
                        <ul class="links" ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                            <li class="link">
                                <a href="classes/Applications.html" data-type="entity-link">Applications</a>
                            </li>
                            <li class="link">
                                <a href="classes/Calendar.html" data-type="entity-link">Calendar</a>
                            </li>
                            <li class="link">
                                <a href="classes/Communications.html" data-type="entity-link">Communications</a>
                            </li>
                            <li class="link">
                                <a href="classes/Filesystem.html" data-type="entity-link">Filesystem</a>
                            </li>
                            <li class="link">
                                <a href="classes/Media.html" data-type="entity-link">Media</a>
                            </li>
                            <li class="link">
                                <a href="classes/Reminders.html" data-type="entity-link">Reminders</a>
                            </li>
                            <li class="link">
                                <a href="classes/Resources.html" data-type="entity-link">Resources</a>
                            </li>
                            <li class="link">
                                <a href="classes/System.html" data-type="entity-link">System</a>
                            </li>
                            <li class="link">
                                <a href="classes/Weather.html" data-type="entity-link">Weather</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#interfaces-links"' :
                            'data-target="#xs-interfaces-links"' }>
                            <span class="icon ion-md-information-circle-outline"></span>
                            <span>Interfaces</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? ' id="interfaces-links"' : 'id="xs-interfaces-links"' }>
                            <li class="link">
                                <a href="interfaces/ApplicationMetadata.html" data-type="entity-link">ApplicationMetadata</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CalendarEvent.html" data-type="entity-link">CalendarEvent</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CalendarEventCreateParameters.html" data-type="entity-link">CalendarEventCreateParameters</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CalendarMetadata.html" data-type="entity-link">CalendarMetadata</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CommunicationsBluetooth.html" data-type="entity-link">CommunicationsBluetooth</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CommunicationsBluetoothDevice.html" data-type="entity-link">CommunicationsBluetoothDevice</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CommunicationsTelephony.html" data-type="entity-link">CommunicationsTelephony</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/CommunicationsWiFi.html" data-type="entity-link">CommunicationsWiFi</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/FilesystemMetadata.html" data-type="entity-link">FilesystemMetadata</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/MediaSupportedActions.html" data-type="entity-link">MediaSupportedActions</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/MediaTrack.html" data-type="entity-link">MediaTrack</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ReminderCreateParameters.html" data-type="entity-link">ReminderCreateParameters</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ReminderEntry.html" data-type="entity-link">ReminderEntry</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/RemindersList.html" data-type="entity-link">RemindersList</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ResourcesBattery.html" data-type="entity-link">ResourcesBattery</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ResourcesMemory.html" data-type="entity-link">ResourcesMemory</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/ResourcesProcessor.html" data-type="entity-link">ResourcesProcessor</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/WeatherAirQualityPollutant.html" data-type="entity-link">WeatherAirQualityPollutant</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/WeatherDaily.html" data-type="entity-link">WeatherDaily</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/WeatherHourly.html" data-type="entity-link">WeatherHourly</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/WeatherMetadata.html" data-type="entity-link">WeatherMetadata</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/WeatherNightly.html" data-type="entity-link">WeatherNightly</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/WeatherNow.html" data-type="entity-link">WeatherNow</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/WeatherUnits.html" data-type="entity-link">WeatherUnits</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#miscellaneous-links"'
                            : 'data-target="#xs-miscellaneous-links"' }>
                            <span class="icon ion-ios-cube"></span>
                            <span>Miscellaneous</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                            <li class="link">
                                <a href="miscellaneous/enumerations.html" data-type="entity-link">Enums</a>
                            </li>
                        </ul>
                    </li>
            </ul>
        </nav>
        `);
        this.innerHTML = tp.strings;
    }
});