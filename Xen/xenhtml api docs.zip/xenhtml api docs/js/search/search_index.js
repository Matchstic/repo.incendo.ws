var COMPODOC_SEARCH_INDEX = {
    "index": {"version":"2.3.8","fields":["title","body"],"fieldVectors":[],"invertedIndex":[],"pipeline":["stemmer"]},
    "store": {}
}
