var Level = "";
var State = "";

function init(){

if (BGColor == "Dark") {document.getElementById("Container").style.backgroundColor= "#000000";}
if (BGColor == "Light"){document.getElementById("Container").style.backgroundColor= "#ffffff";}

document.getElementById("G1Overlay").style.backgroundColor= FrontColor;
document.getElementById("G2Overlay").style.backgroundColor= BackColor;
document.getElementById("H1Overlay").style.backgroundColor= FrontColor;
document.getElementById("H2Overlay").style.backgroundColor= BackColor;

$.ajaxSetup({
cache: false,
headers: {'Cache-Control': 'no-cache'}
});
	
Battery();
Memory(); }

function Battery() {

refreshBatteryTimer = setTimeout(Battery, 16*1000);

jQuery.get('file:///private/var/mobile/Library/BatteryStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var Level=substr[0].split(':')[1];
var State=substr[1].split(':')[1];

if( Level > 0  && Level <= 2 )	{document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_1@2x.png";}
if( Level > 2  && Level <= 5 )	{document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_2@2x.png";}
if( Level > 5 && Level <= 10 )	{document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_3@2x.png";}
if( Level > 10 && Level <= 20 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_4@2x.png";}
if( Level > 20 && Level <= 25 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_5@2x.png";}
if( Level > 25 && Level <= 35 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_6@2x.png";}
if( Level > 35 && Level <= 45 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_7@2x.png";}
if( Level > 45 && Level <= 50 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_8@2x.png";}
if( Level > 50 && Level <= 55 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_9@2x.png";}
if( Level > 55 && Level <= 65 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_10@2x.png";}
if( Level > 65 && Level <= 70 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_11@2x.png";}
if( Level > 70 && Level <= 80 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_12@2x.png";}
if( Level > 80 && Level <= 85 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_13@2x.png";}
if( Level > 85 && Level <= 90 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_14@2x.png";}
if( Level > 90 && Level <= 95 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_15@2x.png";}
if( Level > 95 && Level <= 98 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_16@2x.png";}
if( Level > 98 && Level <= 100 ) {document.getElementById("BatteryImage").src="Images/Battery/BatteryBG_17@2x.png";}


document.getElementById("LevelDisplay").innerHTML = Level +"% ";
document.getElementById("StateDisplay").innerHTML = State;

});

}

function Memory() {

refreshMemoryTimer = setTimeout(Memory, 11*1000);

jQuery.get('file:///private/var/mobile/Library/RAMStats.txt', function(appdata) {

var myvar = appdata;
var substr = appdata.split('\n');
var free = substr[0].split(':')[1];
var Used = substr[1].split(':')[1];

document.getElementById("FreeDisplay").innerHTML = "Free RAM:" + free +"MB";
document.getElementById("UsedDisplay").innerHTML = "Used RAM:" + Used +"MB";

});

}