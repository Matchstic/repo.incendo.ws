// Set BGColor to match your Themes Background Color

var BGColor = "Dark";       //  "Dark" for Black, "Light" for White

// Set these to Change Flip Tiles Front and Back Colors

var FrontColor = "#003300"; //  Hex color for Front Flip Side
var BackColor  = "#003300";  //  Hex color for Back  Flip Side

var FrontColor = "#003300"; //  Hex color for Front Flip Side
var BackColor  = "#003300";  //  Hex color for Back  Flip Side

