Templates for these widgets can be found at http://matchsticrepo.zapto.org/projects/Convergance/Resources.html although for HTML widgets, feel free to use the ones included here as a base. PSD files for icons are included with these templates.

To include an icon for your widget (displayed both in Settings and in Convergance), it must be named Icon@2x.png (or Icon.png for non-retina).

For naming your folder, just copy the style from the other widgets present in this folder.


Objective-C widgets must have their principal class conform to the CVWidgetDelegate protocol. feel free to ask for this, but it'll be also available on my github and the link above.